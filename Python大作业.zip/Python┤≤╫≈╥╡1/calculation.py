from random import *
from tkinter import *
from tkinter.messagebox import *
def easy():
    count=0
    for i in range(10):
        a=randint(0,9)
        b=randint(0,9)
        c=int(input('%d + %d ='%(a,b)))
        if(a+b==c):
            count=count+1
    print('答对题数：%d'%count)
    if count>=8:
        showinfo('数学计算','闯关成功！')
    else:
        showinfo('数学计算','闯关失败')
        
def medium():
    count=0
    for i in range(10):
        a=randint(10,99)
        b=randint(10,99)
        c=int(input('%d + %d ='%(a,b)))
        if(a+b==c):
            count=count+1
    print('答对题数：%d'%count)
    if count>=8:
        showinfo('数学计算','闯关成功！')
    else:
        showinfo('数学计算','闯关失败')
def hard():
    count=0
    for i in range(10):
        a=randint(100,999)
        b=randint(100,999)
        c=int(input('%d + %d ='%(a,b)))
        if(a+b==c):
            count=count+1
    print('答对题数：%d'%count)
    if count>=8:
        showinfo('数学计算','闯关成功！')
    else:
        showinfo('数学计算','闯关失败')


