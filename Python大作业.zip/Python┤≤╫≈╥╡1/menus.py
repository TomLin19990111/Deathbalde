from tkinter import *
from calculation import *
from graphic import *
from tkinter.messagebox import *
def about():
    showinfo('关于','designed by TomLin')

window=Tk()
menubar=Menu(window)

mathmenu=Menu(menubar,tearoff=0)
mathmenu.add_command(label='简单题目',command=easy)
mathmenu.add_command(label='中等题目',command=medium)
mathmenu.add_command(label='困难题目',command=hard)
menubar.add_cascade(label='数学计算',menu=mathmenu)

drawmenu=Menu(menubar,tearoff=0)
drawmenu.add_command(label='画五环图',command=fiverings)
drawmenu.add_command(label='画三叶草',command=clover)
menubar.add_cascade(label='数学画图',menu=drawmenu)


helpmenu=Menu(menubar,tearoff=0)
helpmenu.add_command(label='关于',command=about)
helpmenu.add_separator()
helpmenu.add_command(label='关闭',command=window.destroy)
menubar.add_cascade(label='帮助',menu=helpmenu)
window.config(menu=menubar)
window.mainloop()
