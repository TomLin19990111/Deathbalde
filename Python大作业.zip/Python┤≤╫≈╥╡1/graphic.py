import matplotlib.pyplot as plt
from numpy import *
import turtle
from tkinter import *
def fiverings():
    try:
        turtle.reset()
        t=turtle.getturtle()
    except Exception:
        turtle.reset()
        t=turtle.getturtle()
    Colorlist1=['blue','black','red']
    Colorlist2=['yellow','green']
    t.pensize(4)
    t.speed(10)
    for i in Colorlist1:
        t.pencolor(i)
        t.circle(25)
        t.penup()
        t.forward(60)
        t.pendown()
    t.penup()
    t.goto(30,-25)
    t.pendown()
    for j in Colorlist2:
        t.pencolor(j)
        t.circle(25)
        t.penup()
        t.forward(60)
        t.pendown()
def clover():
    plt.figure(figsize=(6,6))
    t=arange(0,2*pi,0.01)
    wh=600
    hh=600
    x=wh*(2/3)*sin(3*t)*cos(t)
    y=hh*(2/3)*sin(3*t)*sin(t)
    plt.plot(x,y)
    plt.show()
    

