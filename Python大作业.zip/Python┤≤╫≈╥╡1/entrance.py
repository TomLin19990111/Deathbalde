from tkinter import *
from tkinter.messagebox import *
import sqlite3
root=Tk()
root.title('密码验证')
root.geometry('200x150')

def verify():
    flag=0
    con=sqlite3.connect('users.db')
    SQL='''select * from usersdata'''
    Datalist=list(con.execute(SQL))
    con.commit()
    for item in Datalist:
        if (E1.get()==item[0]and E2.get()==item[1]):
            showinfo('密码验证','密码正确，欢迎进入')
            flag=1
            root.destroy()
            import menus
            break
    if(flag==0):
        showinfo('密码验证','密码错误，请重试')
            
        
L1=Label(root,text='用户名：')
L1.place(x=10,y=10)
E1=Entry(root,bd=5,font=12,width=15)
E1.place(x=60,y=10)
L2=Label(root,text='密  码：')
L2.place(x=10,y=60)
E2=Entry(root,bd=5,font=12,width=15)
E2.place(x=60,y=60)
btn1=Button(root,text='验证密码信息',command=verify)
btn1.place(x=60,y=100)
root.mainloop()
