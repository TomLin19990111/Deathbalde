from tkinter import *
root=Tk()
var=IntVar()
def choice():
    if var.get()==0:
        import NEMA下拉菜单
    else:
        import 薪酬设计
L1=Label(root,text='请选择您要使用的模块：')
L1.pack()
R1=Radiobutton(root,variable=var,text='NEMA',value=0)
R1.pack()
R2=Radiobutton(root,variable=var,text='薪酬设计',value=1)
R2.pack()
B1=Button(root,text='选择',command=choice)
B1.pack()

root.mainloop()
