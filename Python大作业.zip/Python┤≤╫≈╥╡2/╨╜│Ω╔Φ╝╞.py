from tkinter import *
from tkinter.messagebox import *
from random import *

def about():
    showinfo('关于','薪资设计')


#纯佣金制
def NEMA_abilities():
    root=Tk()
    root.title("NEMA-纯佣金制")
    root.geometry("300x260")
    L1a=Label(root,text="销售额（或利润）")
    L1a.place(x=10,y=10)
    E1a=Entry(root,bd=5,font=12,width=13)
    E1a.place(x=150,y=10)
    L2a=Label(root,text="提成率(1%-100%)：")
    L2a.place(x=10,y=60)
    E2a=Entry(root,bd=5,font=12,width=13)
    E2a.place(x=150,y=60)
    def cal0():
        L4a=Label(root,text="")
        L4a.place(x=55,y=210)
        resulta=(int(E1a.get())*int(E2a.get()))/100
        ssa="您的薪资为%s," % resulta
        if 0<=resulta<=2000:
            sssa="您的收入水平为：低产"
        elif 2000<resulta<=10000:
            sssa="您的收入水平为：中产"
        elif 10000<resulta<=50000:
            sssa="您的收入水平为：初级小康"
        elif 50000<resulta<=100000:
            sssa="您的收入水平为：高级小康"
        else:
            sssa="您的收入水平为：富有"
        L4a.config(text=ssa+sssa)

    B1a=Button(root,text="确认",width=15,command=cal0)
    B1a.place(x=90,y=160)
    
    root.mainloop()

#纯薪金制

def NEMA_effort():
    root=Tk()
    root.title("NEMA-纯薪金制")
    root.geometry("300x280")
    L1b=Label(root,text="固定工资")
    L1b.place(x=10,y=10)
    E1b=Entry(root,bd=5,font=12,width=13)
    E1b.place(x=150,y=10)
    def cal1():
        L3b=Label(root,text="")
        L3b.place(x=35,y=220)
        resultb=(int(E1b.get())*1)
        ssb="您的工资为%s," % resultb
        if 0<=resultb<=2000:
            sssb="您的收入水平为：低产"
        elif 2001<=resultb<=10000:
            sssb="您的收入水平为：中产"
        elif 10000<=resultb<=50000:
            sssb="您的收入水平为：初级小康"
        elif 50001<=resultb<=100000:
            sssb="您的收入水平为：高级小康"
        else:
            sssb="您的收入水平为：富有"
        L3b.config(text=ssb+sssb)
    B1b=Button(root,text="确认",width=15,command=cal1)
    B1b.place(x=90,y=150)
    root.mainloop()

#基本制

def NEMA_duties():
    root=Tk()
    root.title("NEMA-基本制")
    root.geometry("300x320")
    L1c=Label(root,text="基本工资：")
    L1c.place(x=10,y=10)
    E1c=Entry(root,bd=5,font=12,width=13)
    E1c.place(x=150,y=10)
    L2c=Label(root,text="当期销售额：")
    L2c.place(x=10,y=60)
    E2c=Entry(root,bd=5,font=12,width=13)
    E2c.place(x=150,y=60)
    L3c=Label(root,text="销售定额：")
    L3c.place(x=10,y=110)
    E3c=Entry(root,bd=5,font=12,width=13)
    E3c.place(x=150,y=110)
    L4c=Label(root,text="提成率（1%-100%）：")
    L4c.place(x=10,y=160)
    E4c=Entry(root,bd=5,font=12,width=13)
    E4c.place(x=150,y=160)
    def cal2():
        resultc=(int(E1c.get())+(int(E2c.get())-int(E3c.get()))*int(E4c.get())/100)
        ssc="您的薪资为%s," % resultc
        if 0<=resultc<=2000:
            sssc="您的收入水平为：低产"
        elif 2000<resultc<=10000:
            sssc="您的收入水平为：中产"
        elif 10000<resultc<=50000:
            sssc="您的收入水平为：初级小康"
        elif 50000<resultc<=100000:
            sssc="您的收入水平为：高级小康"
        else:
            sssc="您的收入水平为：富有"
        L5c.config(text=ssc+sssc)
    B1c=Button(root,text="确认",width=15,command=cal2)
    B1c.place(x=90,y=210)
    L5c=Label(root,text="")
    L5c.place(x=55,y=260)
    root.mainloop()

#浮动定额制

def NEMA_careerenvrionments():
    root=Tk()
    root.title("NEMA-浮动定额制")
    root.geometry("300x320")
    L1d=Label(root,text="基本工资：")
    L1d.place(x=10,y=10)
    E1d=Entry(root,bd=5,font=12,width=13)
    E1d.place(x=150,y=10)
    L2d=Label(root,text="个人当期销售额：")
    L2d.place(x=10,y=60)
    E2d=Entry(root,bd=5,font=12,width=13)
    E2d.place(x=150,y=60)
    L3d=Label(root,text="当期浮动定额：")
    L3d.place(x=10,y=110)
    E3d=Entry(root,bd=5,font=12,width=13)
    E3d.place(x=150,y=110)
    L4d=Label(root,text="提成率（1%-100%）：")
    L4d.place(x=10,y=160)
    E4d=Entry(root,bd=5,font=12,width=13)
    E4d.place(x=150,y=160)
    def cal3():
        L3e=Label(root,text="")
        L3e.place(x=55,y=160)
        resultd=(int(E1d.get())+(int(E2d.get())-int(E3d.get()))*int(E4d.get())/100)
        ssd="您的薪资为%s," % resultd
        if 0<=resultd<=2000:
            sssd="您的收入水平为：低产"
        elif 2000<resultd<=10000:
            sssd="您的收入水平为：中产"
        elif 10000<resultd<=50000:
            sssd="您的收入水平为：初级小康"
        elif 50000<resultd<=100000:
            sssd="您的收入水平为：高级小康"
        else:
            sssd="您的收入水平为：富有"
        L3d.config(text=ssd+sssd)
    B1d = Button(root,text="确认",width=15,command=cal3)
    B1d.place(x=180,y=240)
    root.mainloop()

#同期比制

def NEMA_careerenvrionment():
    root=Tk()
    root.title("NEMA-同期比制")
    root.geometry("300x320")
    L1e=Label(root,text="基本工资：")
    L1e.place(x=10,y=10)
    E1e=Entry(root,bd=5,font=12,width=13)
    E1e.place(x=150,y=10)
    L2e=Label(root,text="当期销售额：")
    L2e.place(x=10,y=60)
    E2e=Entry(root,bd=5,font=12,width=13)
    E2e.place(x=150,y=60)
    L3e=Label(root,text="定额：")
    L3e.place(x=10,y=110)
    E3e=Entry(root,bd=5,font=12,width=13)
    E3e.place(x=150,y=110)
    L4e=Label(root,text="提成率（1%-100%）：")
    L4e.place(x=10,y=160)
    E4e=Entry(root,bd=5,font=12,width=13)
    E4e.place(x=150,y=160)
    L5e=Label(root,text="去年同期销售额：")
    L5e.place(x=10,y=210)
    E5e=Entry(root,bd=5,font=12,width=13)
    E5e.place(x=150,y=210)
    def cal3():
        L3d=Label(root,text="")
        L3d.place(x=55,y=250)
        resulte=((int(E1e.get())+(int(E2e.get())-int(E3e.get()))*int(E4e.get())/100))*(int(E2e.get())/int(E5e.get()))
        sse="您的薪资为%s," % resulte
        if 0<=resulte<=2000:
            ssse="您的收入水平为：低产"
        elif 2000<resulte<=10000:
            ssse="您的收入水平为：中产"
        elif 10000<resulte<=50000:
            ssse="您的收入水平为：初级小康"
        elif 50000<resulte<=100000:
            ssse="您的收入水平为：高级小康"
        else:
            ssse="您的收入水平为：富有"
        L3d.config(text=sse+ssse)
    B1d = Button(root,text="确认",width=15,command=cal3)
    B1d.place(x=180,y=280)
    root.mainloop()

root=Tk()
root.geometry('300x300')
menubar=Menu(root)

NEMAmenu=Menu(menubar,tearoff=0)
NEMAmenu.add_command(label="纯佣金制",command=NEMA_abilities)
NEMAmenu.add_command(label="纯薪金制",command=NEMA_effort)
NEMAmenu.add_command(label="基本制",command=NEMA_duties)
NEMAmenu.add_command(label="浮动定额制",command=NEMA_careerenvrionments)
NEMAmenu.add_command(label="同期比制",command=NEMA_careerenvrionment)
menubar.add_cascade(label="薪酬设计",menu=NEMAmenu)

helpmenu=Menu(menubar,tearoff=0)
helpmenu.add_command(label="关于",command=about)
menubar.add_cascade(label="帮助",menu=helpmenu)

root['menu']=menubar

root.mainloop
