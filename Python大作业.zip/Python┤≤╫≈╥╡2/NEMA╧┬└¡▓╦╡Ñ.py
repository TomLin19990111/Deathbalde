from tkinter import *
from tkinter.messagebox import *
from random import *

def about():
    showinfo('关于','NEMA')


#NEMA技能
def NEMA_abilities():
    root=Tk()
    root.title("NEMA-技能")
    root.geometry("300x260")
    L1a=Label(root,text="教育(14-70)：")
    L1a.place(x=10,y=10)
    E1a=Entry(root,bd=5,font=12,width=15)
    E1a.place(x=150,y=10)
    L2a=Label(root,text="经验(22-110)：")
    L2a.place(x=10,y=60)
    E2a=Entry(root,bd=5,font=12,width=15)
    E2a.place(x=150,y=60)
    L3a=Label(root,text="主动性和创造性(14-70)：")
    L3a.place(x=10,y=110)
    E3a=Entry(root,bd=5,font=12,width=15)
    E3a.place(x=150,y=110)
    def cal0():
        L4a=Label(root,text="")
        L4a.place(x=55,y=210)
        resulta=(int(E1a.get())+int(E2a.get()))
        ssa="您的得分为%s," % resulta
        if 0<=resulta<=50:
            sssa="您的等级为：1级"
        elif 51<=resulta<=100:
            sssa="您的等级为：2级"
        elif 101<=resulta<=150:
            sssa="您的等级为：3级"
        elif 151<=resulta<=200:
            sssa="您的等级为：4级"
        else:
            sssa="您的等级为：5级"
        L4a.config(text=ssa+sssa)

    B1a=Button(root,text="确认",width=15,command=cal0)
    B1a.place(x=90,y=160)
    
    root.mainloop()

#NEMA努力

def NEMA_effort():
    root=Tk()
    root.title("NEMA-努力")
    root.geometry("300x280")
    L1b=Label(root,text="体力要求(0-50)：")
    L1b.place(x=10,y=10)
    E1b=Entry(root,bd=5,font=12,width=15)
    E1b.place(x=150,y=10)
    L2b=Label(root,text="精神或视觉要求(0-25)：")
    L2b.place(x=10,y=80)
    E2b=Entry(root,bd=5,font=12,width=15)
    E2b.place(x=150,y=80)
    def cal1():
        L3b=Label(root,text="")
        L3b.place(x=35,y=220)
        resultb=(int(E1b.get())+int(E2b.get()))
        ssb="您的得分为%s," % resultb
        if 0<=resultb<=15:
            sssb="您的等级为：1级"
        elif 16<=resultb<=30:
            sssb="您的等级为：2级"
        elif 31<=resultb<=45:
            sssb="您的等级为：3级"
        elif 46<=resultb<=60:
            sssb="您的等级为：4级"
        else:
            sssb="您的等级为：5级"
        L3b.config(text=ssb+sssb)
    B1b=Button(root,text="确认",width=15,command=cal1)
    B1b.place(x=90,y=150)
    root.mainloop()

#NEMA责任

def NEMA_duties():
    root=Tk()
    root.title("NEMA-责任")
    root.geometry("300x320")
    L1c=Label(root,text="设备或工程(5-25)：")
    L1c.place(x=10,y=10)
    E1c=Entry(root,bd=5,font=12,width=15)
    E1c.place(x=150,y=10)
    L2c=Label(root,text="材料或产品(5-25)：")
    L2c.place(x=10,y=60)
    E2c=Entry(root,bd=5,font=12,width=15)
    E2c.place(x=150,y=60)
    L3c=Label(root,text="他人的安全(5-25)：")
    L3c.place(x=10,y=110)
    E3c=Entry(root,bd=5,font=12,width=15)
    E3c.place(x=150,y=110)
    L4c=Label(root,text="他人的工作(5-25)：")
    L4c.place(x=10,y=160)
    E4c=Entry(root,bd=5,font=12,width=15)
    E4c.place(x=150,y=160)
    def cal2():
        resultc=(int(E1c.get())+int(E2c.get())+int(E3c.get())+int(E4c.get()))
        ssc="您的得分为%s," % resultc
        if 0<=resultc<=20:
            sssc="您的等级为：1级"
        elif 21<=resultc<=40:
            sssc="您的等级为：2级"
        elif 41<=resultc<=60:
            sssc="您的等级为：3级"
        elif 61<=resultc<=80:
            sssc="您的等级为：4级"
        else:
            sssc="您的等级为：5级"
        L5c.config(text=ssc+sssc)
    B1c=Button(root,text="确认",width=15,command=cal2)
    B1c.place(x=90,y=210)
    L5c=Label(root,text="")
    L5c.place(x=55,y=260)
    root.mainloop()

#NEMA-职务环境

def NEMA_careerenvrionments():
    root=Tk()
    root.title("NEMA-职务环境")
    root.geometry("300x220")
    L1d=Label(root,text="作业条件（10－50）：")
    L1d.place(x=10,y=10)
    E1d=Entry(root,bd=5,font=12,width=15)
    E1d.place(x=150,y=10)
    L2d=Label(root,text="不可避免的危险（5－25）：")
    L2d.place(x=10,y=60)
    E2d=Entry(root,bd=5,font=12,width=15)
    E2d.place(x=150,y=60)
    def cal3():
        L3d=Label(root,text="")
        L3d.place(x=55,y=160)
        resultd=(int(E1d.get())+int(E2d.get()))
        ssd="您的得分为%s," % resultd
        if 0<=resultd<=15:
            sssd="您的等级为：1级"
        elif 16<=resultd<=30:
            sssd="您的等级为：2级"
        elif 31<=resultd<=45:
            sssd="您的等级为：3级"
        elif 46<=resultd<=60:
            sssd="您的等级为：4级"
        else:
            sssd="您的等级为：5级"
        L3d.config(text=ssd+sssd)
    B1d = Button(root,text="确认",width=15,command=cal3)
    B1d.place(x=90,y=110)
    root.mainloop()

#NEMA工资等级
from tkinter import*

def salarylevel():     
    root=Tk()
    root.title("NEMA-工资等级")
    root.geometry("900x300")
    L1e=Label(root,text="技能（0-250）：")
    L1e.place(x=300,y=10)
    E1e=Entry(root,bd=5,font=12,width=15)
    E1e.place(x=410,y=10)
    L2e=Label(root,text="努力（0-75）：")
    L2e.place(x=300,y=60)
    E2e=Entry(root,bd=5,font=12,width=15)
    E2e.place(x=410,y=60)
    L3e=Label(root,text="责任（0-100）：")
    L3e.place(x=300,y=110)
    E3e=Entry(root,bd=5,font=12,width=15)
    E3e.place(x=410,y=110)
    L4e=Label(root,text="职务环境（0-75）：")
    L4e.place(x=300,y=160)
    E4e=Entry(root,bd=5,font=12,width=15)
    E4e.place(x=410,y=160)
    def cal4():
        L5e=Label(root,text="")
        L5e.place(x=250,y=260)
        resulte=(int(E1e.get())+int(E2e.get())+int(E3e.get())+int(E4e.get()))
        sse="您的得分为%s," % resulte
        if 101<=resulte<=150:
            ssse="您的工资等级为：1级，您的月工资为250~310美金"
        elif 151<=resulte<=200:
            ssse="您的工资等级为：2级，您的月工资为300~360美金"
        elif 201<=resulte<=250:
            ssse="您的工资等级为：3级，您的月工资为350~410美金"
        elif 251<=resulte<=300:
            ssse="您的工资等级为：4级，您的月工资为400~460美金"
        elif 301<=resulte<=350:
            ssse="您的工资等级为：5级，您的月工资为450~510美金"
        elif 351<=resulte<=400:
            ssse="您的工资等级为：6级，您的月工资为500~560美金"
        elif 401<=resulte<=450:
            ssse="您的工资等级为：7级，您的月工资为550~610美金"
        else:
            ssse="您的工资等级为：8级，您的月工资为600~660美金"
        L5e.config(text=sse+ssse)
    B1e=Button(root,text="确认",width=15,command=cal4)
    B1e.place(x=330,y=210)
    root.mainloop()


root=Tk()
root.geometry('300x300')
menubar=Menu(root)

NEMAmenu=Menu(menubar,tearoff=0)
NEMAmenu.add_command(label="技能",command=NEMA_abilities)
NEMAmenu.add_command(label="努力",command=NEMA_effort)
NEMAmenu.add_command(label="责任",command=NEMA_duties)
NEMAmenu.add_command(label="职务环境",command=NEMA_careerenvrionments)
menubar.add_cascade(label="NEMA分数统计",menu=NEMAmenu)

moneymenu=Menu(menubar,tearoff=0)
moneymenu.add_command(label="工资等级",command=salarylevel)
menubar.add_cascade(label="NEMA工资等级",menu=moneymenu)

helpmenu=Menu(menubar,tearoff=0)
helpmenu.add_command(label="关于",command=about)
menubar.add_cascade(label="帮助",menu=helpmenu)

root['menu']=menubar

root.mainloop
