def cal0():
    resulta=(int(E1a.get())+int(E2a.get()))
    ssa="您的得分为%s," % resulta
    if 0<=resulta<=50:
        sssa="您的等级为：1级"
    elif 51<=resulta<=100:
        sssa="您的等级为：2级"
    elif 101<=resulta<=150:
        sssa="您的等级为：3级"
    elif 151<=resulta<=200:
        sssa="您的等级为：4级"
    else:
        sssa="您的等级为：5级"
    L4a.config(text=ssa+sssa)

def cal1():
    resultb=(int(E1b.get())+int(E2b.get()))
    ssb="您的得分为%s," % resultb
    if 0<=resultb<=15:
        sssb="您的等级为：1级"
    elif 16<=resultb<=30:
        sssb="您的等级为：2级"
    elif 31<=resultb<=45:
        sssb="您的等级为：3级"
    elif 46<=resultb<=60:
        sssb="您的等级为：4级"
    else:
        sssb="您的等级为：5级"
    L3b.config(text=ssb+sssb)

def cal2():
    resultc=(int(E1c.get())+int(E2c.get())+int(E3c.get())+int(E4c.get()))
    ssc="您的得分为%s," % result
    if 0<=resultc<=20:
        sssc="您的等级为：1级"
    elif 21<=resultc<=40:
        sssc="您的等级为：2级"
    elif 41<=resultc<=60:
        sssc="您的等级为：3级"
    elif 61<=resultc<=80:
        sssc="您的等级为：4级"
    else:
        sssc="您的等级为：5级"
    L5c.config(text=ssc+sssc)
    
def cal3():
    resultd=(int(E1d.get())+int(E2d.get()))
    ssd="您的得分为%s," % resultd
    if 0<=resultd<=15:
        sssd="您的等级为：1级"
    elif 16<=resultd<=30:
        sssd="您的等级为：2级"
    elif 31<=resultd<=45:
        sssd="您的等级为：3级"
    elif 46<=resultd<=60:
        sssd="您的等级为：4级"
    else:
        sssd="您的等级为：5级"
    L3d.config(text=ssd+sssd)

def cal4():
    resulte=(int(E1e.get())+int(E2e.get())+int(E3e.get())+int(E4e.get()))
    ss="您的得分为%s," % result
    if 101<=resulte<=150:
        ssse="您的工资等级为：1级，您的月工资为250~310美金"
    elif 151<=resulte<=200:
        ssse="您的工资等级为：2级，您的月工资为300~360美金"
    elif 201<=resulte<=250:
        ssse="您的工资等级为：3级，您的月工资为350~410美金"
    elif 251<=resulte<=300:
        ssse="您的工资等级为：4级，您的月工资为400~460美金"
    elif 301<=resulte<=350:
        ssse="您的工资等级为：5级，您的月工资为450~510美金"
    elif 351<=resulte<=400:
        ssse="您的工资等级为：6级，您的月工资为500~560美金"
    elif 401<=resulte<=450:
        ssse="您的工资等级为：7级，您的月工资为550~610美金"
    else:
        ssse="您的工资等级为：8级，您的月工资为600~660美金"
    L5e.config(text=sse+ssse)
     
        
